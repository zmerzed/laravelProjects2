<div>Name: <span>{{$name}}</span></div>
<div>
Message: 
<br>
{{$bodyMessage}}
</div>