<div id="logout_box" class="modal fade">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
               <p class="text-center">Are you sure?</p>
            </div>
        </div>
    </div>
</div>