<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Property;
use App\Unit;
use Auth;
use Lang;
use DB;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $property = new Property;
        $unit = new Unit;

        $units = Unit::select();
        $hasFields = false;
        $units->whereHas('property', function ($query) USE ($request, $property) {
            
            if($request->has('address') && trim($request->address))  
                $query->where('address', 'like', "%{$request->address}%");

            if($request->has('property_type') && in_array($request->property_type, array_keys($property->types)))
                $query->where('property_type', '=', $request->property_type);

            if($request->has('gender')) {
                $query->where('gender', '=', $request->gender);
            }
        });

       

        if($request->has('furnishing') && in_array($request->furnishing, array_keys($unit->furnishings))) 
            $units->where('furnishing', '=', $request->furnishing);

        if($request->has('terms') && in_array($request->terms, ['LONG', 'SHORT']))
            $units->where('rental_terms', '=', $request->terms);

        if($request->has('bedrooms') && is_numeric($request->bedrooms))
            $units->where('bedrooms', '=', $request->bedrooms);

        if($request->has('bathrooms') && is_numeric($request->bathrooms))
            $units->where('bathrooms', '=', $request->bathrooms);

        if($request->has('capacity') && is_numeric($request->capacity))
            $units->where('bedrooms', '=', $request->capacity);

        if($request->has('min_price') && is_numeric($request->min_price)){
            $units->where(function($query) USE ($request) {
                if($request->has('terms') && $request->terms === 'LONG'){
                    $query->where('long_term_rate', '>=', $request->min_price);
                }

                if($request->has('terms') && $request->terms === 'SHORT'){
                    $query->where('short_term_daily_rate', '>=', $request->min_price)
                    ->orWhere('short_term_weekly_rate', '>=', $request->min_price)
                    ->orWhere('short_term_monthly_rate', '>=', $request->min_price);
                }   
            });
        }

        if($request->has('max_price') && is_numeric($request->max_price)){
            $units->where(function($query) USE ($request) {
                if($request->has('terms') && $request->terms === 'LONG'){
                    $query->where('long_term_rate', '<=', $request->max_price);
                }

                if($request->has('terms') && $request->terms === 'SHORT'){
                    $query->where('short_term_daily_rate', '<=', $request->max_price)
                    ->orWhere('short_term_weekly_rate', '<=', $request->max_price)
                    ->orWhere('short_term_monthly_rate', '<=', $request->max_price);
                }   
            });
        }
        $favorites = array();
        if($request->has('fav')) {
            $tfavorites = DB::table('favorites')->where('user',Auth::user()->id)->get();
            $strs = '';
            foreach($tfavorites as $fav) {
                $strs .= (string) $fav->unit . ',';
            }
            $favorites = explode(',', $strs);
            $byFav = true;
         //   dd($favorites);
            $f_units = $units->approved()->with('property')->paginate(2000);
        }else{
            $byFav = false;
            $f_units = $units->approved()->with('property')->paginate(3);
        }
       

      //  dd($f_units);
        $sug_units = false;
        if(count($f_units) <= 0) {
             $sug_units = Unit::limit(3)->get();
        }
        $brgys = lang::get('barangay');
        return view('home', [
           'types' => $property->types,
           'furnishing' => $unit->furnishings,
           'amenities' => $unit->amenitiesList,
           'units' => $f_units,
           'brgys' => $brgys['brgys'],
           'byFav' => $byFav,
           'favorites' => $favorites,
           'sug_units' => $sug_units
        ]);
    }
}
