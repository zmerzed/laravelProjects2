<?php $__env->startSection('content'); ?>
<div class="container">
	<h3>CHANGE PASSWORD</h3>
	<?php if($messages): ?>
	<div class="bs-callout bs-callout-danger">
		<ul class="list-unstyled">
			<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($message); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>
	<?php if($errors->any()): ?>
      <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

  <?php endif; ?>

	<form action="/profile/changepassword" method="POST" style="margin-bottom: 30px">
  	<?php echo e(csrf_field()); ?>

    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
  	<div class="form-group">
        <label>Old Password: </label>
        <input type="password" class="form-control" placeholder="old password" name="old_password">
    </div>
    <div class="form-group">
        <label>New Password: </label>
        <input type="password" class="form-control" placeholder="new password" name="password">
    </div>
    <div class="form-group">
        <label>Repeat Password: </label>
        <input type="password" class="form-control" placeholder="repeat password" name="rpassword">
    </div>

    <button type="submit" class="btn btn-default">Update</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>