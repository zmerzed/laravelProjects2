<div id="appointment_box" class="modal fade">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
            	<form method="POST" action="/properties/<?php echo e($property->id); ?>/units/<?php echo e($unit->id); ?>/appointments">
            	<?php echo e(csrf_field()); ?>

               <div class="form-group">
	               <label>Date and Time</label>
	                <div class='input-group date' id='datetimepicker1'>
	                    <input type='text' class="form-control" name="date" required="" />
	                    <span class="input-group-addon">
	                        <span class="glyphicon glyphicon-calendar"></span>
	                    </span>
	                </div>
	            </div>
	            <div class="form-group">
	               <label>Tenant</label>
	               <select class="form-control" name="user_id" required="">
	               		<option value="" selected></option>
	               		<?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	               			<option value="<?php echo e($tenant->user->id); ?>"><?php echo e($tenant->user->firstname); ?> <?php echo e($tenant->user->lastname); ?></option>
	               		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	               </select>
	            </div>
	            <button type="submit" class="btn btn-primary">Create</button>
	            </form>
            </div>
        </div>
    </div>
</div>