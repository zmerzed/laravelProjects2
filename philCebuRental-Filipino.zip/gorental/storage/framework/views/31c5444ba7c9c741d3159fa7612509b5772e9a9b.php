<?php $__env->startSection('content'); ?>
<div class="container" style="margin-bottom: 20px">
    <table class="table">
        <h3>Profile</h3>
        <?php if(is_null($user->profile_picture)): ?>
        <img src="/images/preview_default_profile.png" style="max-width: 100%; height: 80px;" />
        <?php else: ?>
        <img src="<?php echo e(asset("storage/{$user->profile_picture}")); ?>" style="max-width: 100%; height: 80px" />
        <?php endif; ?>
        <?php if($user->login_type == 'PROPERTY_OWNER'): ?>
        <a class="btn btn-primary" style="margin-left: 20px">Property Owner</a>
        <?php else: ?>
        <a class="btn btn-primary" style="margin-left: 20px">Tenant</a>
        <?php endif; ?>
        <tbody>
          <tr>
            <td>Name</td>
            <td><?php echo e($user->fullname()); ?></td>
          </tr>
          <tr>
            <td>Gender</td>
            <td><?php echo e($user->gender); ?></td>
          </tr>
          <tr>
            <td>Mobile</td>
            <td><?php echo e($user->mobile_number); ?></td>
          </tr>
        </tbody>
    </table>    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>