<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.breadcrumbs'); ?>
        <p class="lnk_pag"><a> pending units</a> </p>
    <?php echo $__env->renderComponent(); ?>

    <div class="spacer-30"></div>
    <div class="container">
      <div class="row">
          <div class="col-sm-12">
            <section id="feat_propty">
                <div class="container">
                        <div class="row">
                            <div class="titl_sec">
                                <div class="col-xs-6">

                                    <h3 class="main_titl text-left">
                                <?php echo e($label_unit); ?>

                            </h3>

                                </div>
                                <div class="clearfix"></div>
                            </div>

                            <?php $__empty_1 = true; $__currentLoopData = $units->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="panel panel-default unit-item" data-lat="<?php echo e($unit->property->latitude); ?>" data-lng="<?php echo e($unit->property->longitude); ?>" data-address="<?php echo e($unit->property->address); ?>">
                                            <div class="panel-image tile" style="background-image:url(<?php if(isset($unit->property->photos['primary'])): ?><?php echo e(asset("storage/{$unit->property->photos['primary'][0]}")); ?><?php endif; ?>);background-size:cover;background-position:center;background-repeat:no-repeat;">
                                                <!-- <img class="img-responsive img-hover" src="<?php if(isset($unit->property->photos['primary'])): ?><?php echo e(asset("storage/{$unit->property->photos['primary'][0]}")); ?><?php endif; ?>" alt=""> -->
                                                <div class="img_hov_eff">
                                                    <a class="btn btn-default btn_trans" href="<?php echo e(url("units/{$unit->id}/view")); ?>"> More Details </a>
                                                </div>

                                            </div>

                                            <div class="panel-body">
                                                <div class="prop_feat">
                                                    <p class="area"><i class="fa fa-home"></i> <?php echo e($unit->property->getTypeDescription()); ?></p>
                                                    <p class="bedrom"><i class="fa fa-bed"></i> <?php echo e($unit->bedrooms); ?> Bed(s)</p>
                                                    <p class="bedrom"><i class="fa fa-bath"></i> <?php echo e($unit->bathrooms); ?> Bath(s)</p>
                                                </div>
                                                <h3 class="sec_titl"><?php echo e($unit->property->building_name); ?></h3>

                                                <p class="sec_desc">
                                                    <?php echo e($unit->property->address); ?>

                                                    <table class="table table-condensed">
                                                        <tr>
                                                            <td>Rental Term</td>
                                                            <td class="text-right"><strong><?php echo e($unit->rental_terms === 'LONG' ? 'Long Term' :  'Short Term'); ?></strong></td>
                                                            <?php if($unit->rental_terms === 'LONG'): ?>
                                                                <tr>
                                                                    <td>Rate</td>
                                                                    <td class="text-right"><strong>Php <?php echo e(number_format($unit->long_term_rate, 2)); ?></strong></td>
                                                                </tr>
                                                            <?php else: ?>

                                                                <tr>
                                                                    <td>Daily Rate</td>
                                                                    <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_daily_rate, 2)); ?></strong></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Weekly Rate</td>
                                                                    <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_weekly_rate, 2)); ?></strong></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Monthly Rate</td>
                                                                    <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_monthly_rate, 2)); ?></strong></td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        </tr>
                                                    </table>
                                                </p>
                                            </div>
                                        </div>


                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-md-12">
                                <div class="bs-callout bs-callout-danger" >
                                    No units to approve
                                </div>
                                </div>
                            <?php endif; ?>

                        </div>
                        <!-- /.row -->
                </div>
                     <!-- /.container -->
            </section>
          </div>
      </div>
            
    </div>
        <div class="spacer-60"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>