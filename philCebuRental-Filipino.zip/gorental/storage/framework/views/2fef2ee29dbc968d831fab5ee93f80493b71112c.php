<?php $__env->startSection('content'); ?>
    <section id="feat_propty">
        <div class="container">
            <div class="row">
                <div class="titl_sec">
                    <div class="col-xs-6">
                        <h3 class="main_titl text-left">MY APPOINTMENTS</h3>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!-- /.container -->
    </section>
    <section id="feat_propty">
        <div class="container">
            <div class="row">
                <div class="titl_sec appointments">
                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="media">
                        <div class="media-left">
                            <a href="#">
                                <?php if(!is_null($appointment->unit->user->profile_picture)): ?>
                                <img class="media-object" src="<?php echo e(asset("storage/{$appointment->unit->user->profile_picture}")); ?>" alt="..." style="width:60px;height:60px">
                                <?php else: ?>
                                <img class="media-object" src="/images/preview_default_profile.png" alt="..." style="width:60px;height:60px">
                                <?php endif; ?>

                            </a>
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading"><a href="/users/<?php echo e($appointment->unit->user->id); ?>"><?php echo e($appointment->unit->user->fullname()); ?></a></h4>
                            <p><?php echo e($appointment->address); ?></p>
                            <?php echo e($appointment->date); ?> 
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!-- /.container -->
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- GMaps JavaScript -->
<!-- <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyC1MUjOwwLeP2Jv5Q8o0nt5RH-oSKY5RUw"></script> -->
<script src="http://maps.google.com/maps/api/js?libraries=places&region=uk&language=en&sensor=false"></script>
    <script src="<?php echo e(asset('js/infobox.js')); ?>"></script>
    <script src="<?php echo e(asset('js/markerwithlabel_packed.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom_map.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>