<footer>
    <!-- Copyright -->
    <div class="footer_copy_right">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 text-left">
                    <p>&copy; Copyright 2017. All Rights Reserved by <a href="#"> <?php echo e(config('app.name')); ?> </a>
                    | <a href="/contact">Contact Us</a>
                    </p>
                </div>
                <div class="col-sm-6 text-right">
                    <p>Template developed by <a href="javascript:void(0)"> The <?php echo e(config('app.name')); ?> Team </a> </p>

                </div>     
            </div>
        </div>
    </div>
</footer>