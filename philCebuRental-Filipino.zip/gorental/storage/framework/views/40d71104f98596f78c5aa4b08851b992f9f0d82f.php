<?php $__env->startSection('content'); ?>
<div class="container">
	<h3>EDIT PROFILE</h3>
	<?php if(isset($messages)): ?>
	<div class="bs-callout bs-callout-danger">
		<ul class="list-unstyled">
			<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($message); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>
	<?php if($errors->any()): ?>
        <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

<?php endif; ?>

	<form action="/profile" method="POST" enctype="multipart/form-data" style="margin-bottom: 30px">
	<?php echo e(csrf_field()); ?>

	<div class="form-group">
      <label>Username: </label>
      <input type="text" class="form-control" placeholder="user name" value="<?php echo e(Auth::user()->username); ?>" name="username">
    </div>
	<div class="form-group">
      <label>First name:</label>
      <input type="text" class="form-control" placeholder="first name" value="<?php echo e(Auth::user()->firstname); ?>" name="firstname">
    </div>
    <div class="form-group">
      <label>Last name:</label>
      <input type="text" class="form-control" placeholder="Last name" value="<?php echo e(Auth::user()->lastname); ?>" name="lastname">
    </div>
    <div class="form-group">
      <label>Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" value="<?php echo e(Auth::user()->email); ?>" name="email">
    </div>
    <div class="form-group">
      <label>Mobile No:</label>
      <input type="text" class="form-control" placeholder="mobile number" value="<?php echo e(Auth::user()->mobile_number); ?>" name="mobile_number">
    </div>
    <div class="form-group">
	  <label>Gender</label>
	  <select class="form-control" name="gender">
	    <option value="MALE">Male</option>
	    <option value="FEMALE">Female</option>
	  </select>
	 </div>
    <div class="form-group">
        <div class="controls">
            <label for="">Profile Picture</label>
            <input type="file" name="profile_picture">
        </div>
    </div>       
    <button type="submit" class="btn btn-default">Update</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>