<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.breadcrumbs'); ?>
        <p class="lnk_pag"><a> my properties </a> </p>
    <?php echo $__env->renderComponent(); ?>
    <div class="spacer-60"></div>
    <div class="container">
        <div class="row">
            <!-- Properties Section -->
            <section id="feat_propty">
                <div class="container">
                    <?php $__empty_1 = true; $__currentLoopData = $properties->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row">
                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <div class="col-md-4">
                                    <div class="panel panel-default">
                                        <div class="panel-image tile" style="background-image:url(<?php if(isset($property->photos['primary'])): ?><?php echo e(asset("storage/{$property->photos['primary'][0]}")); ?> <?php endif; ?>);background-size:cover;background-position:center;background-repeat:no-repeat;">
                                            <!-- <img class="img-responsive img-hover" src="<?php if(isset($property->photos['primary'])): ?><?php echo e(asset("storage/{$property->photos['primary'][0]}")); ?> <?php endif; ?>" alt=""> -->
                                            <div class="img_hov_eff">
                                                <a href="<?php echo e(url("properties/{$property->id}/units")); ?>" class="btn btn-default btn_trans"> View units</a>
                                            </div>
                                        </div>
                                       <!--  <div class="sal_labl">
                                            For Sale
                                        </div> -->

                                        <div class="panel-body">
                                            <div class="prop_feat">
                                                <ul class="list-unstyled">
                                                    <li><i class="fa fa-home"></i> <?php if($property->extension): ?> <?php echo e($property->extension); ?> - <?php endif; ?> <?php echo e($property->address); ?></li>
                                                    <li><i class="fa fa-cog"></i> <?php echo e($property->getTypeDescription()); ?></li>
                                                </ul>
                                            </div>
                                            <h3 class="sec_titl"><?php echo e($property->building_name); ?></h3>
                                            <div class="panel_bottom">
                                                <div class="col-md-6">
                                                    <a href="/properties/<?php echo e($property->id); ?>" class="btn btn-primary"> Edit</a>
                                                    <a href="/deleteproperty?property=<?php echo e($property->id); ?>" class="btn btn-primary"> Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?> 
                </div>
                <!-- /.container -->
            </section>
            <div class="spacer-60"></div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>