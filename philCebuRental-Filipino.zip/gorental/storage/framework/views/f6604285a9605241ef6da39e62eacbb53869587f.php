<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.breadcrumbs'); ?>
        <?php $__env->slot('banner'); ?>
        <div class="pag_titl_sec">
            <h1 class="pag_titl"> <?php echo e($property->building_name); ?> </h1>
            <h4 class="sub_titl">  <?php echo e($property->address); ?> </h4>
        </div>
        <?php $__env->endSlot(); ?>
        <p class="lnk_pag"><a href="<?php echo e(url('/properties')); ?>"> properties </a> </p>
        <p class="lnk_pag"> / </p>
        <p class="lnk_pag"><a> units </a> </p>
    <?php echo $__env->renderComponent(); ?>
    <div class="spacer-60"></div>
    <div class="container">
        <div class="row">
            <!-- Proerty Details Section -->
            <section id="feat_propty">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                              <a href="<?php echo e(url("properties/{$property->id}/units/create")); ?>" class="btn btn-primary">Create new unit</a>
                        </div>
                    </div>
                    <div class="spacer-20"></div>
                    <?php $__empty_1 = true; $__currentLoopData = $units->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row">
                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <div class="col-md-4">
                                    <div class="panel panel-default">
                                        <div class="panel-image img" style="background-image:url(<?php echo e(asset("storage/{$unit->photos}")); ?>);background-position:center;background-size:cover;background-repeat:no-repeat;height: 190px;">
                                            <!-- <img class="img-responsive img-hover" src="<?php echo e(asset("storage/{$unit->photos}")); ?>" alt=""> -->
                                            <div class="img_hov_eff">
                                                <a href="/properties/<?php echo e($property->id); ?>/units/<?php echo e($unit->id); ?>" class="btn btn-default btn_trans"> Edit</a>
                                            </div>
                                        </div>
                                        <div class="panel-body" style="padding-bottom:20px">
                                            <div class="prop_feat">
                                                <table class="table table-condensed">
                                                    <tbody>
                                                        <?php if($unit->rental_terms === 'LONG'): ?>
                                                            <tr><td colspan="2" class="warning text-center">Long Term Rate</td></tr>
                                                        <tr><td>Monthly</td> <td colspan="2" class="text-right"><strong>Php <?php echo e(number_format($unit->long_term_rate, 2)); ?></strong></td></tr>
                                                        <?php else: ?>
                                                            <tr><td colspan="2" class="warning text-center">Short Term Rate</td> </tr>
                                                        <tr><td>Daily</td> <td colspan="2" class=" text-right"><strong>Php <?php echo e(number_format($unit->short_term_daily_rate, 2)); ?></strong></td></tr>
                                                        <tr><td>Weekly</td> <td colspan="2" class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_weekly_rate, 2)); ?></strong></td></tr>
                                                        <tr><td>Monthly</td> <td colspan="2" class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_monthly_rate, 2)); ?></strong></td></tr>
                                                        <?php endif; ?>
                                                        
                                                    </tbody>
                                                </table>
                                            </div>
                                            Status:
                                            <?php if($unit->isAvailable()): ?>
                                                <a href="?unit=<?php echo e($unit->id); ?>&status=1" class="btn btn-primary btn-xs">Vacant</a>
                                                <a href="?unit=<?php echo e($unit->id); ?>&status=0" class="btn btn-default btn-xs">Occupied</a>
                                            <?php else: ?>
                                                <a href="?unit=<?php echo e($unit->id); ?>&status=1" class="btn btn-default btn-xs">Vacant</a>
                                                <a href="?unit=<?php echo e($unit->id); ?>&status=0" class="btn btn-primary btn-xs">Occupied</a>
                                            <?php endif; ?>
                                            <a href="/properties/<?php echo e($property->id); ?>/units/<?php echo e($unit->id); ?>/view" class="btn btn-primary btn-xs">View Appointments</a>    
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="spacer-40"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                     <div class="row">
                         <div class="col-sm-12">
                             <div class="bs-callout bs-callout-warning text-ceter">No units have been added for this property</div>
                         </div>
                     </div>
                    <?php endif; ?>

                </div>
                <!-- /.container -->
            </section>
            <div class="spacer-60"></div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>