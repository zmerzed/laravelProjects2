<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .status p {
    font-size: 0.8em;
    margin: 0;
}
.status {
    /* border: 1px solid; */
    background: #ddd;
    padding: 10px;
}
    </style>
    <section id="feat_propty">
        <div class="container">
            <div class="row">
                <div class="titl_sec">
                    <div class="col-xs-6">
                        <h3 class="main_titl text-left">MY APPOINTMENTS</h3>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!-- /.container -->
    </section>
    <section id="feat_propty">
        <div class="container">
            <div class="row">
                <?php if(Auth::user()->login_type == 'USER'): ?>
                <div class="titl_sec appointments">
                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="media">
                        <div class="media-left">
                            <a href="#">
                                <?php if(!is_null($appointment->unit->user->profile_picture)): ?>
                                <img class="media-object" src="<?php echo e(asset("storage/{$appointment->unit->user->profile_picture}")); ?>" alt="..." style="width:60px;height:60px">
                                <?php else: ?>
                                <img class="media-object" src="/images/preview_default_profile.png" alt="..." style="width:60px;height:60px">
                                <?php endif; ?>

                            </a>
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading"><a href="/users/<?php echo e($appointment->unit->user->id); ?>"><?php echo e($appointment->unit->user->fullname()); ?></a> <?php if($appointment->status == 'DECLINE'): ?> <small>has decline your appointment</small> <?php endif; ?></h4>
                            <p><?php if($appointment->property->extension): ?> <?php echo e($appointment->property->extension); ?> - <?php endif; ?> <?php echo e($appointment->address); ?></p>
                            <?php echo e($appointment->date); ?> 
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="clearfix"></div>
                </div>
                <?php endif; ?>
                <?php if(Auth::user()->login_type == 'PROPERTY_OWNER'): ?>
                <div class="titl_sec appointments">
                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="media">
                        <div class="media-left">
                            <a href="#">
                                <?php if(!is_null($appointment->user->profile_picture)): ?>
                                <img class="media-object" src="<?php echo e(asset("storage/{$appointment->user->profile_picture}")); ?>" alt="..." style="width:60px;height:60px">
                                <?php else: ?>
                                <img class="media-object" src="/images/preview_default_profile.png" alt="..." style="width:60px;height:60px">
                                <?php endif; ?>
                            </a>
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading"><a href="/users/<?php echo e($appointment->user->id); ?>"><?php echo e($appointment->user->fullname()); ?></a></h4>
                            <p><?php if($appointment->property->extension): ?> <?php echo e($appointment->property->extension); ?> - <?php endif; ?> <?php echo e($appointment->address); ?></p>
                            <?php echo e($appointment->date); ?> 
                            <div class="clearfix"></div>
                            <div class="status">
                                <?php if($appointment->status == 'ACCEPT'): ?>
                                    <p>Status: <span>APPROVED</span></p>
                                <?php elseif($appointment->status == 'DECLINE'): ?>
                                    <p>Status: <span>DECLINED</span></p>
                                <?php else: ?>
                                    <p>Status: <span>PENDING</span></p>
                                <?php endif; ?>
                                <?php if($appointment->status == 'ACCEPT'): ?>
                                    <a href="/appointments/<?php echo e($appointment->id); ?>/1" class="btn btn-default btn-sm">ACCEPT</a>
                                    <a href="/appointments/<?php echo e($appointment->id); ?>/-1" class="btn btn-primary btn-sm">DECLINE</a>
                                <?php elseif($appointment->status == 'DECLINE'): ?>
                                    <a href="/appointments/<?php echo e($appointment->id); ?>/1" class="btn btn-primary btn-sm">ACCEPT</a>
                                    <a href="/appointments/<?php echo e($appointment->id); ?>/-1" class="btn btn-default btn-sm">DECLINE</a>
                                <?php else: ?>
                                     <a href="/appointments/<?php echo e($appointment->id); ?>/1" class="btn btn-primary btn-sm">ACCEPT</a>
                                    <a href="/appointments/<?php echo e($appointment->id); ?>/-1" class="btn btn-primary btn-sm">DECLINE</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="clearfix"></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- /.container -->
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- GMaps JavaScript -->
<!-- <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyC1MUjOwwLeP2Jv5Q8o0nt5RH-oSKY5RUw"></script> -->
<script src="http://maps.google.com/maps/api/js?libraries=places&region=uk&language=en&sensor=false"></script>
    <script src="<?php echo e(asset('js/infobox.js')); ?>"></script>
    <script src="<?php echo e(asset('js/markerwithlabel_packed.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom_map.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>