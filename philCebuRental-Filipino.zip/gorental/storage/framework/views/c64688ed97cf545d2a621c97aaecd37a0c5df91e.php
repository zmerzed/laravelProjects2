<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.breadcrumbs'); ?>
        <p class="lnk_pag"><a> notifications</a> </p>
    <?php echo $__env->renderComponent(); ?>

    <div class="spacer-30"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="list-group">
                    <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="list-group-item <?php echo e(isset($currentThread) && $currentThread == $t->sender_id ? 'active': ''); ?>"  href="<?php echo e(url('/notifications', ['partner' => $t->sender_id])); ?>">
                            <?php if((int)$t->unseen_count): ?>
                                <span class="badge"><?php echo e($t->unseen_count); ?></span>
                            <?php endif; ?>
                            <?php echo e($t->sender); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-sm-8">
                <?php if(!isset($currentThread)): ?>
                    <p class="text-center"><i class="fa fa-envelope fa-3x"></i></p>
                    <p class="text-center">
                        
                        Select a person to chat in the left!
                    </p>
                <?php else: ?>
                    <div class="row">
                        <div class="col-sm-12" style="max-height:50vh;overflow:auto;margin-bottom:10px" id="message-box">
                            <?php 
                                $userDP = Auth::user()->profile_picture;
                             ?>
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media">
                                <div class="media-left">
                                    <a href="#">
                                        <img class="media-object" src="<?php if($m->sent_from == Auth::id()): ?> <?php if(!is_null($userDP)): ?><?php echo e(asset("storage/{$userDP}")); ?> <?php else: ?> /images/preview_default_profile.png <?php endif; ?> <?php else: ?> <?php if(!is_null($partnerInfo->profile_picture)): ?><?php echo e(asset("storage/{$partnerInfo->profile_picture}")); ?> <?php else: ?> /images/preview_default_profile.png <?php endif; ?> <?php endif; ?>" alt="..." style="width:60px;height:60px">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><?php echo e($m->sent_from == Auth::id() ?  'You' : $partnerInfo->fullname()); ?> <small><?php echo e(date_create($m->created_at)->format('m/d/Y \@ h:i A')); ?> </small></h4>
                                    <?php echo e($m->message); ?> 
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </div>
                    <div class="row">
                        <form method="post" action="<?php echo e(url('/send-message', ['partner' => $currentThread])); ?>" class="ajax">
                            <div class="col-sm-10">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <textarea class="form-control" name="message"></textarea>
                                </div>
                                
                            </div>
                            <div class="col-sm-2">
                                <button type="submit" class="btn btn-primary">Send</button>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
            
    </div>
        <div class="spacer-30"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
    
        $(document).ready(function(){
            var objDiv = document.getElementById("message-box");
            objDiv.scrollTop = objDiv.scrollHeight;
        })  
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>