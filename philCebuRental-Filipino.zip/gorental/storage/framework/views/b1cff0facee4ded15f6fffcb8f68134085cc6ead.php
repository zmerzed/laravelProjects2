<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.breadcrumbs'); ?>
        <p class="lnk_pag"><a> view tenants </a> </p>
    <?php echo $__env->renderComponent(); ?>

    <div class="spacer-30"></div>
    <div class="container">
      <div class="row">
          <div class="col-sm-12">
            <section id="feat_propty">
                <div class="container">
                        <div class="row">
                            <div class="titl_sec">
                                <div class="col-xs-6">

                                    <h3 class="main_titl text-left">
                               USER TYPE:  <?php echo e($user_type); ?> 
                            </h3>

                                </div>
                                <div class="clearfix"></div>
                            </div>

                            <?php if(empty($users)): ?>
                                 <div class="col-md-12">
                                    <div class="bs-callout bs-callout-danger" >
                                        No tenants to show
                                    </div>
                                </div>
                            

                            <?php else: ?>

                                <div class="row">

                                    <div class="col-sm-12">
                                        <form class="form-inline" action="<?php echo e(url('admin/users')); ?>">
                                           <!--<div class="row">-->
                                               <input type="hidden" name="type" value="<?php echo e($type); ?>">
                                               <div class="form-group">
                                                    <label class="sr-only">Name</label>
                                                    <input type="text" class="form-control" name="name" placeholder="Name">
                                                </div>
                                                <div class="radio">
                                                    <label>
                                                    <input name="gender"  value="MALE" type="radio"> Male
                                                    </label>
                                                </div>
                                                <div class="radio">
                                                    <label> 
                                                    <input type="radio" name="gender"  value="FEMALE"> Female
                                                    </label>
                                                </div>
                                                <div class="radio">
                                                    <label> 
                                                    <input type="radio" name="gender"  value=""> All gender
                                                    </label>
                                                </div>
                                           <!--</div>-->
                                            <button type="submit"  class="btn btn-primary">Search</button>
                                        </form>
                                        <table  data-toggle="table" data-show-print="true" class="table" style="margin-top:10px;">
                                            <thead>
                                                <tr>
                                                    <th>First Name</th>
                                                    <th>Last Name</th>
                                                    <th>Username</th>
                                                    <th>Email</th>
                                                    <th>Gender</th>
                                                    <th>Mobile Number</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($row->firstname); ?></td>
                                                        <td><?php echo e($row->lastname); ?></td>
                                                        <td><?php echo e($row->username); ?></td>
                                                        <td><?php echo e($row->email); ?></td>
                                                        <td><?php echo e($row->gender); ?></td>
                                                        <td><?php echo e($row->mobile_number); ?></td>
                                                        <td>
                                                            <?php if($row->status == 'ENABLE'): ?>
                                                                <a href="/admin/users<?php echo e($url_params); ?>user=<?php echo e($row->id); ?>&enable=true" class="btn btn-sm btn-primary">Enable</a>
                                                                <a href="/admin/users<?php echo e($url_params); ?>user=<?php echo e($row->id); ?>&enable=false" class="btn btn-sm btn-default">Disable</a>
                                                            <?php else: ?>
                                                                <a href="/admin/users<?php echo e($url_params); ?>user=<?php echo e($row->id); ?>&enable=true" class="btn btn-sm btn-default">Enable</a>
                                                                <a href="/admin/users<?php echo e($url_params); ?>user=<?php echo e($row->id); ?>&enable=false" class="btn btn-sm btn-primary">Disable</a>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                                 

                            <?php endif; ?>

                           

                        </div>
                        <!-- /.row -->
                </div>
                     <!-- /.container -->
            </section>
          </div>
      </div>
            
    </div>
        <div class="spacer-30"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>