<div>Name: <span><?php echo e($name); ?></span></div>
<div>
Message: 
<br>
<?php echo e($bodyMessage); ?>

</div>