<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.breadcrumbs'); ?>
        <?php $__env->slot('banner'); ?>
        <div class="pag_titl_sec">
            <h1 class="pag_titl"> <?php echo e($unit->property->building_name); ?> </h1>
            <h4 class="sub_titl">  <?php echo e($unit->property->address); ?> </h4>
        </div>
        <?php $__env->endSlot(); ?>
        <p class="lnk_pag"><a > view unit</a> </p>
    <?php echo $__env->renderComponent(); ?>

    <div class="spacer-60"></div>
    <div class="container">
        <div class="row">
            <!-- Proerty Details Section -->
            <section id="prop_detal" class="col-md-8">
                <div class="row">
                    <div class="panel panel-default">
                       <!-- Proerty Slider Images -->
                        <div class="panel-image">
                            <ul id="prop_slid">
                                <?php $__currentLoopData = $unit->allPhotos(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="unit-slider" style="background-image:url(<?php echo e(asset("storage/{$photo}")); ?>)">
                                    <!-- <img class="img-responsive" src="<?php echo e(asset("storage/{$photo}")); ?>" alt="Property Slide Image"> -->
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div class="clearfix"></div>
                        </div>

                        <div class="panel-body">    
                           
                            <h3 class="sec_titl"><?php echo e($unit->property->building_name); ?> <small></small></h3>
                            

                            <p class="sec_desc">
                                
                               <?php echo e($unit->property->address); ?> (Permit # <?php echo e($unit->property->permit_number); ?>)

                                <div class="prop_feat">
                                <p class="area"><i class="fa fa-home"></i> <?php echo e($unit->property->getTypeDescription()); ?></p>
                                <p class="bedrom"><i class="fa fa-bed"></i>  <?php echo e($unit->bedrooms); ?> Bedrooms</p>
                                <p class="bedrom"><i class="fa fa-shower"></i> <?php echo e($unit->bathrooms); ?> Bathrooms</p>
                                <p class="bedrom"><i class="fa fa-paint-brush"></i> <?php echo e($unit->furnishings[$unit->furnishing]); ?></p>
                                <?php if(!$isMyFavorite): ?>
                                    <?php if(Auth::check() && Auth::user()->id !=  $unit->created_by): ?>
                                        <p class="bedrom"><a href="/addfavorite?unit=<?php echo e($unit->id); ?>"><i class="fa fa-star-o"></i> Add to Favorites </a></p>
                                    <?php elseif(!Auth::check()): ?>
                                        <p class="bedrom"><a href="" data-toggle="modal" data-target="#login_box"><i class="fa fa-star-o"></i> Add to Favorites </a></p>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>

                               <table class="table" style="margin-top:10px;">
                                    <tr>
                                        <td>Rental Term</td>
                                        <td class="text-right"><strong><?php echo e($unit->rental_terms === 'LONG' ? 'Long Term' :  'Short Term'); ?></strong></td>
                                        
                                    </tr>
                                    <?php if($unit->rental_terms === 'LONG'): ?>
                                            <tr>
                                                <td>Rate</td>
                                                <td class="text-right"><strong>Php <?php echo e(number_format($unit->long_term_rate, 2)); ?></strong></td>
                                            </tr>
                                        <?php else: ?>
                                            <tr>
                                                <td>Daily Rate</td>
                                                <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_daily_rate, 2)); ?></strong></td>
                                            </tr>
                                            <tr>
                                                <td>Weekly Rate</td>
                                                <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_weekly_rate, 2)); ?></strong></td>
                                            </tr>
                                            <tr>
                                                <td>Monthly Rate</td>
                                                <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_monthly_rate, 2)); ?></strong></td>
                                            </tr>
                                        <?php endif; ?>
                                        <tr>
                                        <td>Inclusions</td>
                                        <td class="text-right"><strong><?php echo e($unit->inclusions); ?></strong></td>
                                        
                                    </tr>
                                </table>

                                <div class="row">
                                    <div class="tags_sec">
                                        <?php if(!is_null($unit->amenities)): ?>
                                        <?php $__currentLoopData = $unit->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tags_box">
                                                <a><i class="fa fa-check"></i> <?php echo e($a); ?>  </a>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                        <?php endif; ?>       

                                    </div>
                                </div>
                            </p>

                        </div>
                    </div>
                </div>
                <!-- /.row -->
                <div class="spacer-30"></div>
                
                <!-- Proerty Map -->

                <div class="row">
                    <div class="titl_sec">
                        <div class="col-lg-12">
                            <h3 class="main_titl text-left">Property Map</h3>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="col-md-12">
                        <div class="prop_map unit-map" id="map" style="height:300px">
                           
                        </div>

                    </div>
                </div>
                <!-- /.row -->


            </section>

            <!-- Sidebar Section -->       
                          
            <section id="sidebar" class="col-md-4">
                  <!-- Agent Info -->
                <div class="row">
                    <div class="agen_info">
                        <div class="col-md-12">
                            <div class="panel panel-default">

                                <div class="panel-body">
                                <a><img class="img-circle img-thumbnail img-responsive img-hover center-block" src="<?php echo e(asset($unit->property->owner->profile_picture)); ?>" alt="" style="display:none;"></a>
                                    <div class="row agen_desc">
                                        <h3 class="sec_titl text-center" style="margin-top:10px;">
                                            Appointments                               
                                        </h3>
                                    </div>
                                    <div class="panel_bottom" style="padding:0px">
                                        <div class="list-group">
                                            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <li href="" class="list-group-item"><?php echo e($appointment->date); ?> 
                                                <a class="btn btn-primary btn-xs pull-right" style="margin-left: 10px" href="/appointments/<?php echo e($appointment->id); ?>/delete">Delete</a><div class="pull-right">To: <?php echo e($appointment->username); ?></div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <button class="btn btn-primary" data-toggle="modal" data-target="#appointment_box">Set an appointment</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

                <div class="spacer-30"></div>

            </section>

            <div class="spacer-60"></div>

        </div>
    </div>
<div id="notif-box" class="modal fade" style="z-index:10000">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Send a message</h4>
                </div>
                <div class="modal-body">
                    <div class="log_form">
                        <form method="POST" action="<?php echo e(url('/send-message', ['partner' => $unit->property->created_by])); ?>" class="ajax" data-next="<?php echo e(url('/notifications')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="bs-callout bs-callout-danger hidden"></div>
                            <div class="control-group form-group">
                                <div class="controls">
                                    <textarea  class="form-control" name="message"></textarea>
                                </div>

                                <div class="clearfix"></div>

                                <button type="submit" class="btn btn-primary">Send</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if(Auth::check() && Auth::user()->login_type === 'ADMIN'): ?>
    <div id="approve-unit" class="modal fade" style="z-index:10000">
        <div class="modal-dialog modal-sm">
            <div class="modal-content ">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Confirm action</h4>
                </div>
                <div class="modal-body">
                    <div class="log_form">
                        <form method="POST" action="<?php echo e(route('approve-unit', ['unit' => $unit->id])); ?>" class="ajax" data-next="<?php echo e(url('/admin')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <p class="text-center">Are you sure?</p>
                            <button type="submit" class="btn btn-primary" style="margin-bottom:10px;">Yes</button>
                            <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('property-owner.modal-set-appointment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startPush('scripts'); ?>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC1MUjOwwLeP2Jv5Q8o0nt5RH-oSKY5RUw&callback=initMap"></script>
    <script src="<?php echo e(asset('js/jquery.bxslider.min.js')); ?>"></script>
   <script type="text/javascript">  
    $('#datetimepicker1').datetimepicker();
    function initMap() {
        var myLatLng = {lat: <?php echo e($unit->property->latitude); ?>, lng:<?php echo e($unit->property->longitude); ?> };

        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 18,
          center: myLatLng,
           mapTypeId: 'satellite'
        });

        var marker = new google.maps.InfoWindow({
          position: myLatLng,
          map: map,
          content: '<p class="text-center lead"><i class="fa fa-home"></i> <?php echo e($unit->property->building_name); ?></p><?php echo e($unit->property->address); ?>'
        });
    }

     $(document).ready(function () {
        'use strict';

        $('#prop_slid').bxSlider({
            pagerCustom: '#slid_nav'
        });

    });
   </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>