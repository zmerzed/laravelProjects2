   
<?php $__env->startSection('content'); ?>
 <!-- Header Property Map -->
  <?php if(Session::has('success')): ?>
       <div class="alert alert-info"><?php echo e(Session::get('success')); ?></div>
    <?php endif; ?>
    
    <header id="banner" class="stat_bann" <?php if($byFav): ?> style="display: none" <?php endif; ?>>
        <div class="bannr_sec2">
            <div id="map"></div>
            <div class="clearfix"></div>
        </div>
    </header>
    <!-- Page Content -->
    <section id="srch_slide" <?php if($byFav): ?> style="display: none" <?php endif; ?>>

        <div class="container">

            <!-- Search Form -->
            <div class="row">
                <div class="col-md-12">
                    <div class="srch_frm">
                        <h3>unit Search</h3>
                        <form name="sentMessage" id="contactForm" novalidate>
                            <div class="control-group form-group">
                                <div class="controls col-md-3 first">
                                    <label>Address </label>
                                    <input id="searchTextField" type="text" class="form-control" name="address" value="<?php echo e(request()->address); ?>"> 
                                   <!--  <select name="address" class="form-control">
                                     <?php $__currentLoopData = $brgys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </select> -->
                                </div>

                                <div class="controls col-md-3">
                                     <label>Property Type </label>
                                        <select name="property_type" class="form-control">
                                        <option ></option>
                                         <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val); ?>" <?php echo e(request()->property_type == $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="controls col-md-3">
                                    <label>Furnishing </label>
                                    <select name="furnishing"class="form-control">
                                        <option></option>
                                        <?php $__currentLoopData = $furnishing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val); ?>" <?php echo e(request()->furnishing == $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="controls col-md-3">
                                    <label>Terms </label>
                                    <?php 
                                        $types = ['LONG' => 'Long Term (6 monhts or more)', 'SHORT' => 'Short Term (A few nights or weeks)']
                                     ?>
                                    <select name="terms" class="form-control" >
                                        <option></option>
                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val); ?>" <?php echo e(request()->terms == $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="clearfix"></div>
                            </div>

                            <div class="control-group form-group">
                                <div class="controls col-md-3 first">
                                    <label>Bedrooms </label>
                                    <?php 
                                        $bedrooms = array_combine(range(1, 5), range(1, 5))
                                     ?>
                                    <select name="bedrooms" class="form-control" >
                                        <option></option>
                                        <?php $__currentLoopData = $bedrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val); ?>"  <?php echo e(request()->bedrooms == $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="controls col-md-3">
                                    <label>Bathrooms </label>
                                    <?php 
                                        $bathrooms = array_combine(range(1, 5), range(1, 5))
                                     ?>
                                    <select name="bathrooms" class="form-control" >
                                        <option></option>
                                        <?php $__currentLoopData = $bathrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val); ?>" <?php echo e(request()->bathrooms == $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="controls col-md-3">
                                    <label>Min. Price </label>
                                    <input name="min_price" type="text" class="form-control" value="<?php echo e(request()->min_price); ?>">
                                </div>
                                <div class="controls col-md-3">
                                    <label>Max. Price </label>
                                    <input name="max_price" type="text" class="form-control" value="<?php echo e(request()->max_price); ?>">
                                </div>
                                 <div class="controls col-md-3 first">
                                    <label>Capacity</label>
                                    <input name="capacity" type="text" class="form-control" value="<?php echo e(request()->capacity); ?>">
                                </div>
                                <div class="controls col-md-3 ">
                                    <label>Gender</label>
                                    <select name="gender" class="form-control" >
                                        <option></option>
                                        <option value="MALE">MALE</option>
                                        <option value="FEMALE">FEMALE</option>
                                        <option value="BOTH">BOTH</option>
                                    </select>
                                </div>
                                <div class="clearfix"></div>
                            </div>

                            <div class="control-group form-group">
                                <?php $__currentLoopData = array_chunk($amenities, (int)count($amenities)/3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-sm-3">
                                    <?php $__currentLoopData = $col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <div class="checkbox">
                                        <label><input type="checkbox" name="amenities[]"  value="<?php echo e($a); ?>" <?php echo e(in_array($a, (array)request()->amenities) ? 'checked' : ''); ?>><?php echo e($a); ?></label>
                                      </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                <div class="clearfix"></div>
                            </div>
                            <button type="submit" class="btn btn-primary">Search</button>
                            <div class="clearfix"></div>
                            <div id="success"></div>
                            <!-- For success/fail messages -->
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container -->

    </section>

    <div class="spacer-60"></div>

    <!-- Featured Properties Section -->
    <section id="feat_propty">
        <div class="container">
            <div class="row">
                <div class="titl_sec">
                    <div class="col-xs-6">
                        <?php if($byFav): ?>
                            <h3 class="main_titl text-left">MY FAVORITES</h3>
                        <?php else: ?>
                            <h3 class="main_titl text-left">UNIT RESULTS</h3>
                        <?php endif; ?>

                    </div>
                    <div class="clearfix"></div>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $units->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($unit->user->isEnable()): ?>
                        <?php if($byFav): ?> 
                            <?php if(in_array((string)$unit->id, $favorites)): ?>
                                <div class="col-md-4 rental-feed">
                                    <div class="panel panel-default unit-item" data-lat="<?php echo e($unit->property->latitude); ?>" data-lng="<?php echo e($unit->property->longitude); ?>" data-address="<?php echo e($unit->property->address); ?>">
                                    <div class="panel-image tile" style="background-image:url(<?php if(isset($unit->property->photos['primary'])): ?> <?php echo e(asset("storage/{$unit->property->photos['primary'][0]}")); ?><?php endif; ?>);background-size: cover;background-repeat: no-repeat;background-position: center;">
                                        <img style="display:none;" class="img-responsive img-hover" src="<?php if(isset($unit->property->photos['primary'])): ?> <?php echo e(asset("storage/{$unit->property->photos['primary'][0]}")); ?><?php endif; ?>" alt="">
                                        <div class="img_hov_eff">
                                            <a class="btn btn-default btn_trans" href="<?php echo e(route('view-unit', ['unit' => $unit->id])); ?>"> More Details </a>
                                        </div>
                                        <div class="sal_labl">
                                            Vacant
                                        </div>
                                    </div>

                                    <div class="rental-home-feed panel-body">
                                        <div class="prop_feat">
                                            <p class="area"><i class="fa fa-home"></i> <?php echo e($unit->property->getTypeDescription()); ?></p>
                                            <p class="bedrom"><i class="fa fa-bed"></i> <?php echo e($unit->bedrooms); ?> Bed(s)</p>
                                            <p class="bedrom"><i class="fa fa-bath"></i> <?php echo e($unit->bathrooms); ?> Bath(s)</p>
                                        </div>
                                        <h3 class="sec_titl"><?php echo e($unit->property->building_name); ?> <a href="/removefavorite?unit=<?php echo e($unit->id); ?>" class="btn btn-primary pull-right" style="color:#fff">Remove</a></h3>

                                        <p class="sec_desc">
                                            <?php echo e($unit->property->address); ?> 
                                            <br>
                                            <span class="nearby-the-property">Landmark: <?php echo e($unit->property->landmarks); ?> </span>
                                            <table class="table table-condensed">
                                                <tr>
                                                    <td>Rental Term</td>
                                                    <td class="text-right"><strong><?php echo e($unit->rental_terms === 'LONG' ? 'Long Term' :  'Short Term'); ?></strong></td>
                                                    <?php if($unit->rental_terms === 'LONG'): ?>
                                                        <tr>
                                                            <td>Rate</td>
                                                            <td class="text-right"><strong>Php <?php echo e(number_format($unit->long_term_rate, 2)); ?></strong></td>
                                                        </tr>
                                                    <?php else: ?>

                                                        <tr>
                                                            <td>Daily Rate</td>
                                                            <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_daily_rate, 2)); ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Weekly Rate</td>
                                                            <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_weekly_rate, 2)); ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Monthly Rate</td>
                                                            <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_monthly_rate, 2)); ?></strong></td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tr>
                                            </table>
                                        </p>
                                    </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($unit->isAvailable()): ?>
                            <div class="col-md-4 rental-feed">
                                <div class="panel panel-default unit-item" data-lat="<?php echo e($unit->property->latitude); ?>" data-lng="<?php echo e($unit->property->longitude); ?>" data-address="<?php echo e($unit->property->address); ?>">
                                <div class="panel-image tile" style="background-image:url(<?php if(isset($unit->property->photos['primary'])): ?> <?php echo e(asset("storage/{$unit->property->photos['primary'][0]}")); ?><?php endif; ?>);background-size: cover;background-repeat: no-repeat;background-position: center;">
                                    <img style="display:none;" class="img-responsive img-hover" src="<?php if(isset($unit->property->photos['primary'])): ?> <?php echo e(asset("storage/{$unit->property->photos['primary'][0]}")); ?><?php endif; ?>" alt="">
                                    <div class="img_hov_eff">
                                        <a class="btn btn-default btn_trans" href="<?php echo e(route('view-unit', ['unit' => $unit->id])); ?>"> More Details </a>
                                    </div>
                                    <div class="sal_labl">
                                        Vacant
                                    </div>
                                </div>

                                <div class="rental-home-feed panel-body">
                                    <div class="prop_feat">
                                        <p class="area"><i class="fa fa-home"></i> <?php echo e($unit->property->getTypeDescription()); ?></p>
                                        <p class="bedrom"><i class="fa fa-bed"></i> <?php echo e($unit->bedrooms); ?> Bed(s)</p>
                                        <p class="bedrom"><i class="fa fa-bath"></i> <?php echo e($unit->bathrooms); ?> Bath(s)</p>
                                    </div>
                                    <h3 class="sec_titl"><?php echo e($unit->property->building_name); ?></h3>

                                    <p class="sec_desc">
                                        <?php echo e($unit->property->address); ?>

                                        <br>
                                        <span class="nearby-the-property"> Landmark: <?php echo e($unit->property->landmarks); ?> </span>
                                        <table class="table table-condensed">
                                            <tr>
                                                <td>Rental Term</td>
                                                <td class="text-right"><strong><?php echo e($unit->rental_terms === 'LONG' ? 'Long Term' :  'Short Term'); ?></strong></td>
                                                <?php if($unit->rental_terms === 'LONG'): ?>
                                                    <tr>
                                                        <td>Rate</td>
                                                        <td class="text-right"><strong>Php <?php echo e(number_format($unit->long_term_rate, 2)); ?></strong></td>
                                                    </tr>
                                                <?php else: ?>

                                                    <tr>
                                                        <td>Daily Rate</td>
                                                        <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_daily_rate, 2)); ?></strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Weekly Rate</td>
                                                        <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_weekly_rate, 2)); ?></strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Monthly Rate</td>
                                                        <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_monthly_rate, 2)); ?></strong></td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tr>
                                        </table>
                                    </p>
                                </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                     <div class="col-md-12">
                    <div class="bs-callout bs-callout-danger" >
                        No results matched your search
                    </div>
                    </div>
                <?php endif; ?>

            </div>
            <?php if(count($units) > 0): ?>
            <?php echo e($units->render()); ?>

            <?php endif; ?>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>

    <?php if($sug_units): ?>
    <section id="feat_propty">
        <div class="container">
            <div class="row">
                <div class="titl_sec">
                    <div class="col-xs-6">
                        <h3 class="main_titl text-left">SUGGESTIONS</h3>
                    </div>
                    <div class="clearfix"></div>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $sug_units->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($unit->isAvailable()): ?>
                            <div class="col-md-4 rental-feed">
                                <div class="panel panel-default unit-item" data-lat="<?php echo e($unit->property->latitude); ?>" data-lng="<?php echo e($unit->property->longitude); ?>" data-address="<?php echo e($unit->property->address); ?>">
                                <div class="panel-image tile" style="background-image:url(<?php if(isset($unit->property->photos['primary'])): ?> <?php echo e(asset("storage/{$unit->property->photos['primary'][0]}")); ?><?php endif; ?>);background-size: cover;background-repeat: no-repeat;background-position: center;">
                                    <img style="display:none;" class="img-responsive img-hover" src="<?php if(isset($unit->property->photos['primary'])): ?> <?php echo e(asset("storage/{$unit->property->photos['primary'][0]}")); ?><?php endif; ?>" alt="">
                                    <div class="img_hov_eff">
                                        <a class="btn btn-default btn_trans" href="<?php echo e(route('view-unit', ['unit' => $unit->id])); ?>"> More Details </a>
                                    </div>
                                    <div class="sal_labl">
                                        Vacant
                                    </div>
                                </div>

                                <div class="rental-home-feed panel-body">
                                    <div class="prop_feat">
                                        <p class="area"><i class="fa fa-home"></i> <?php echo e($unit->property->getTypeDescription()); ?></p>
                                        <p class="bedrom"><i class="fa fa-bed"></i> <?php echo e($unit->bedrooms); ?> Bed(s)</p>
                                        <p class="bedrom"><i class="fa fa-bath"></i> <?php echo e($unit->bathrooms); ?> Bath(s)</p>
                                    </div>
                                    <h3 class="sec_titl"><?php echo e($unit->property->building_name); ?></h3>

                                    <p class="sec_desc">
                                        <?php echo e($unit->property->address); ?>

                                        <br>
                                        <span class="nearby-the-property"> Landmark: <?php echo e($unit->property->landmarks); ?> </span>
                                        <table class="table table-condensed">
                                            <tr>
                                                <td>Rental Term</td>
                                                <td class="text-right"><strong><?php echo e($unit->rental_terms === 'LONG' ? 'Long Term' :  'Short Term'); ?></strong></td>
                                                <?php if($unit->rental_terms === 'LONG'): ?>
                                                    <tr>
                                                        <td>Rate</td>
                                                        <td class="text-right"><strong>Php <?php echo e(number_format($unit->long_term_rate, 2)); ?></strong></td>
                                                    </tr>
                                                <?php else: ?>

                                                    <tr>
                                                        <td>Daily Rate</td>
                                                        <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_daily_rate, 2)); ?></strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Weekly Rate</td>
                                                        <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_weekly_rate, 2)); ?></strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Monthly Rate</td>
                                                        <td class="text-right"><strong>Php <?php echo e(number_format($unit->short_term_monthly_rate, 2)); ?></strong></td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tr>
                                        </table>
                                    </p>
                                </div>
                                </div>
                            </div>
                            <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </div>
        </div>
        <!-- /.container -->
    </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- GMaps JavaScript -->
<!-- <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyC1MUjOwwLeP2Jv5Q8o0nt5RH-oSKY5RUw"></script> -->
<script src="http://maps.google.com/maps/api/js?libraries=places&region=uk&language=en&sensor=false"></script>
    <script src="<?php echo e(asset('js/infobox.js')); ?>"></script>
    <script src="<?php echo e(asset('js/markerwithlabel_packed.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom_map.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>